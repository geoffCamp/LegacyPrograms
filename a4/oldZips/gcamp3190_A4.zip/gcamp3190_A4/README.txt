- All programs will be compiled with "make"

Ada:
 - gnatmake -Wall adaqueens.adb
 - queensA.txt must pre-exist

Fortran:
 - gfortran -Wall forqueens.f95 -o forqueens
 - queensF.txt must pre-exist

C:
 - gcc -Wall -std=c99 cqueens.c -o cqueens
